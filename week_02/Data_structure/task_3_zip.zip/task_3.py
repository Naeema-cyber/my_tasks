#Task 1. 
#Write a program to take a string input from the user and display it in uppercase.
#text = "i like python"
#print(text.upper())


#2
#Given the string "python", print its first and last characters
#name = "python"
#print(name[0])
#print(name[-1])


#3
#Ask the user for their name and print "hello,!" where is the user's input
#name = input("your first name")
#print(f"Hello!{name}.")


#4 
#Write a program to count the number of characters in a string without using len()
#word = "underscore"
#print(word.count())


#5
#given "Hello World", replace "Word" with "Python"

#text = "Hello World"
#print(text.replace ("World", "Python"))


#Task 2
#6
#Check if a given string contains the substring "python" (case-insensitive)
#word = "Hello World"
#print("Hello" in word)
#print("World" in word)


#7
#Write a program to reverse a string without using slicing([::-1])



#8
#Given a string with extra spaces, remove the leading and trailing spaces
#text = "          Lagos         "
#print(text.strip())



#9
#Ask the user to enter a sentence and print the number of vowels in it.




#10
#Convert a string "1234" to an integer and multiply it by 2
number = int("1234")
print(number * 2)



#Task 3
#11
#Given "apple, banana, orange", split the string into a list of fruits.
fruits = "apple, banana, orange"
print(fruits.split())



#12
#Ask the user for a sentence and print each word on a new line.
sentence1= input("write a sentence")
sentence2 = input("write a second sentence")
print(f"{sentence1}\n{sentence2}")


#13
#Replace all spaces in a string with underscores(_)



#14
#Count how many times the letter "a" apperars in "Banana"
word = 'Banana'
print(word.count("a"))


#15
#Check if a given string starts with "https://"

url = "https://www.publicacademy.com"
print(url.startswith("https://"))